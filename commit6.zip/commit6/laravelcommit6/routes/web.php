<?php

use App\Http\Controllers\CobaController;
use Illuminate\Support\Facades\Route;

/*
@@ -13,8 +13,11 @@
|
*/


Route::get('' , [CobaController::class, 'index']);
Route::get('/friends' , [CobaController::class, 'index']);
Route::get('/friends/create' , [CobaController::class, 'create']);
Route::post('/friends/store' , [CobaController::class, 'store']); 
Route::get('', [CobaController::class, 'index']);
Route::get('/friends', [CobaController::class, 'index']);
Route::get('/friends/create', [CobaController::class, 'create']);
Route::post('/friends', [CobaController::class, 'store']);
Route::get('/friends/{id}', [CobaController::class, 'show']);
Route::get('/friends/{id}/edit', [CobaController::class, 'edit']);
Route::put('/friends/{id}', [CobaController::class, 'update']);
Route::delete('/friends/{id}', [CobaController::class, 'destroy']); 

